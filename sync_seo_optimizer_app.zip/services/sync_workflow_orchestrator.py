import config
from services import seo_analysis_service

class SyncSEOOrchestrator:
    def get_available_workflows(self):
        return {
            "seo_optimizer": {
                "name": "SEO Optimizer",
                "description": "Analyze and optimize your website SEO with AI"
            }
        }

    def queue_workflow(self, workflow_type, workflow_data):
        if config.FORCE_MOCK_MODE:
            # Run synchronously and return result immediately
            return self._run_sync(workflow_type, workflow_data)
        else:
            raise NotImplementedError("Live mode requires Celery and Redis")

    def _run_sync(self, workflow_type, workflow_data):
        url = workflow_data.get("url", "https://example.com")
        site_data = seo_analysis_service.fetch_site_data(url)
        technical = seo_analysis_service.analyze_technical_seo(site_data)
        recommendations = seo_analysis_service.generate_content_recommendations(site_data)
        generated = seo_analysis_service.ai_content_generator(site_data)

        result_id = "mock-sync-result"
        return {
            "status": "completed",
            "result_id": result_id,
            "workflow_type": workflow_type,
            "progress": 100,
            "site_data": site_data,
            "technical_analysis": technical,
            "recommendations": recommendations,
            "generated_content": generated
        }

    def check_workflow_status(self, result_id):
        return {
            "status": "completed",
            "progress": 100,
            "result_id": result_id
        }

    def get_workflow_results(self, result_id):
        return {
            "result_id": result_id,
            "status": "completed",
            "workflow_type": "seo_optimizer",
            "site_data": {},
            "technical_analysis": {},
            "recommendations": {},
            "generated_content": {}
        }